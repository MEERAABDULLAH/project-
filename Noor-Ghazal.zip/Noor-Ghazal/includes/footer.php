<footer>
    <p>&copy; 2024 My App</p>
</footer>
